var cat_age, cat_sp, cat_name;

cat_age=1;
cat_sp="코숏";
cat_name="나비";

var sum;
sum=cat_age+cat_sp+cat_name;

alert(sum);