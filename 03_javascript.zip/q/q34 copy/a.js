var arr=new Array();

arr=[1,2,3,4];

var num1,num2;
document.write(arr);
document.write("<br>");
num1=arr[1];
document.write("<br>");
num2=arr[3];

document.write(num1+num2);
