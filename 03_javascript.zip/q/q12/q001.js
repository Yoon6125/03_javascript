// var num=100;

// if(num>1){
//     alert("크다");
// }else{
//     alert("작다");
// }

//입력받은 값을 100과 비교하여 크다 작다 판단
var num;
num=prompt("값을 입력하세요")

if(num>100){
    alert("100보다 크다");
}else{
    alert("100보다 작다");
}