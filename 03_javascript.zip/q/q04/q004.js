var cat;
cat= prompt("고양이 수를 입력하세요:");

for(i=0 ; i<cat; i++){
    document.write("<img src='cat.png'>");
    // document.write("<hr>");
}