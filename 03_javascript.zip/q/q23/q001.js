

var random=Math.floor(Math.random()*10)+1;


for(i=1; i<11; i++){
    document.write(i);
    if(i==random){
        break;
    }

}