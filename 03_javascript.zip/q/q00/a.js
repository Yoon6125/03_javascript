document.write("헬로월드!");
document.write("자바 스크립트 테스트");
document.write("<h1>자바 스크립트 테스트</h1>");
document.write("<img src='cat.png'>자바 스크립트 테스트");
confirm("헬로 월드")
prompt("헬로 월드")
var a=100;
var b;
var c;

b=20;
c=a+b;


document.write(c);
