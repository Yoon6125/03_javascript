var arr=new Array();

arr=["개","고양이","너구리"];

var num1,num2;
document.write(arr);

num1=arr[0];

num2=arr[1];

document.write(num1+num2);
