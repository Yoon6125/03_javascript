// var cat=0;

for(i=0 ; i<5; i++){
    document.write("고양이");
    document.write("<hr>");
}