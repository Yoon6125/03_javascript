var r=1;

for(i=0 ; i<10 ;i++){
    document.write(r);
    document.write("<br>");
    r++;
}