function addCatAndInputText(){
    var a=prompt("값 입력: ");
    document.write("고양이"+a);

}


addCatAndInputText();
