function Cat(){
    this.name="";
    this.age=0;
    this.color="";

}




var kitten= new Cat();

kitten.name="새끼고양이";
kitten.age=1;



document.write(kitten.name);
document.write(kitten.age);