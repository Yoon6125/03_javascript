for(a=1; a<=10; a++){
    if(a%2==1){
        document.write("홀수");
    }
    else if(a%2 !=1){
        document.write("짝수");
    }

}