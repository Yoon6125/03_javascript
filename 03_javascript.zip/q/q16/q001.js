var r=1;

while(r<11){
    document.write(r);
    r++;
 }
