// var cat;
// cat= prompt("고양이 수를 입력하세요:");

var r=Math.floor(Math.random()*100)+1;

for(i=1 ; i<=r; i++){
    document.write(i+"<img src='cat.png'>");
    // document.write("<hr>");
}