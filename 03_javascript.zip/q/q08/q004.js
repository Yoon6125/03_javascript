// var cube;

var r=Math.floor(Math.random()*6)+1;


switch(r){
    case 1:
        document.write("<img src='눈1.png'>");
        break;
    case 2:
        document.write("<img src='눈2.png'>");
        break;
    case 3:
        document.write("<img src='눈3.png'>");
        break;
    case 4:
        document.write("<img src='눈4.png'>");
        break;
    case 5:
        document.write("<img src='눈5.png'>");
        break;
    case 6:
        document.write("<img src='눈6.png'>");
        break;

}