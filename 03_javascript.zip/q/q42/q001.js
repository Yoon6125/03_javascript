function return100(){

    return 100;
}
function return200(){

    return 200;
}

function addreturn(a,b){
    var sum=a+b;
    return sum;
}

var s =addreturn(return100(),return200());

document.write(s);