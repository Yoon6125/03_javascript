// ****************
// 수 입력만큼 고양이 마리수 출력
// var b;
// b=prompt("수를 입력하세요:")


// for(var i=0;i<=b;i=i+1){
//     document.write("고양이");
//     if(i==b){
//         document.write("마지막입니다."+"<br>"+"고양이는 총"+b+"마리 입니다.")
//     }
//     else{
//         document.write(i+"마리"+"<br>");
//     }
// }

// // 로그 체크
// console.log("헬로월드!!!");

// function a(){
//     alert("고양이");

// }
// function r(x){
//     var r= Math.floor(Math.random()*x+1);
//     return r;
// }

// document.write(r(300));

function add(a,b){
    //

    var sum =a+b;
    

    return sum;
}

add(1,2);

function Car(){
    this.name="";
    this.size=0;
    this.speed=0;
    this.prise=0;
    this.drive= function(){
        document.write(this.name+" 차가 "+this.speed+" 로 달린다.");
    }
    // function drive(name,speed){
    //     document.write(name+"차가 "+speed+" 속도로 달린다.");
    // }

}

var car1= new Car();
var car2= new Car();
var car3= new Car();


car1.name="승용차";
car2.name="화물용차";
car3.name="경주용차";

car1.size=10;
car2.size=40;
car3.size=15;

car1.speed=20;
car2.speed=10;
car3.speed=50;

car1.prise=100;
car2.prise=150;
car3.prise=200;


document.write(car1.name);
document.write(car1.size);
document.write(car1.speed);
document.write(car1.prise);

document.write("<hr>");
document.write(car2.name);
document.write(car2.size);
document.write(car2.speed);
document.write(car2.prise);

document.write("<hr>");
document.write(car3.name);
document.write(car3.size);
document.write(car3.speed);
document.write(car3.prise);

document.write("<hr>");
car1.drive();
car2.drive();
car3.drive();

// drive(car1.name , car1.speed);
// drive(car2.name , car2.speed);
// drive(car3.name , car3.speed);


